function onUpdateDatabase()
	return false
end
