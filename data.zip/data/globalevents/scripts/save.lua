function onThink(interval)
	saveServer()
	return true
end
