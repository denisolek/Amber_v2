function onEquip(player, item, slot)
	item:remove(1)
	
	return true
end
