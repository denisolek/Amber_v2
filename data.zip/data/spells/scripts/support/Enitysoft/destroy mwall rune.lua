function onCastSpell(creature, variant, isHotkey)
	return false
end
